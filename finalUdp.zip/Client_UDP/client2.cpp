#ifndef UNICODE
#define UNICODE
#endif

#define WIN32_LEAN_AND_MEAN

#include <winsock2.h>
#include <Ws2tcpip.h>
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <thread>
#include <vector>
#include <conio.h>
#include <pthread.h>
#define DEFAULT_BUFLEN 512
#define PREFIXLEN 11
// Link with ws2_32.lib
#pragma comment(lib, "Ws2_32.lib")
char IP_ADDRESS[]="192.168.213.1";

struct data_pair
{
    int number;
    char data[DEFAULT_BUFLEN];
};
int getData(char *recvbuf,int &number,char* data)
{
    char *buf = strtok(recvbuf, " ");
    char numberbuf[DEFAULT_BUFLEN];
    strcpy(numberbuf,buf);
    buf = strtok(NULL, " ");
    strcpy(data,buf);
    number = atoi(numberbuf);

    return 0;
}

int readUDP(SOCKET socket,char* recvbufn,int recvbuflen)
{
    std::vector <int>numbers;
    std::vector <char*>packets;
    strcpy(recvbufn,"");
    char tempbuf[DEFAULT_BUFLEN];
    char recvbuf[DEFAULT_BUFLEN+PREFIXLEN];
    int recvBytes=0;
    int iResult=0;
    while(recvBytes<recvbuflen)
    {
        fd_set readset;
        int result;
        do
        {
            FD_ZERO(&readset);
            FD_SET(socket, &readset);
            result = select(socket + 1, &readset, NULL, NULL, NULL);
        }
        while (result == -1 && errno == EINTR);

        if (result > 0)
        {
            if (FD_ISSET(socket, &readset))
            {
                iResult=recv(socket,recvbuf,sizeof(recvbuf),0);

                //printf("%s \n",recvbuf);
            }
        }
        if(iResult<0)
        {
            return -1;
        }
        /*approve*/
        char app[2]="a";
        send(socket,app,sizeof(app),0);

        char message[DEFAULT_BUFLEN];
        int number;
        getData(recvbuf, number,message);
    //    printf("%d %s \n",number,message);
      //  printf("%s \n",message);
        char*temp=new char();
        strcpy(temp,message);
        packets.push_back(temp);
        numbers.push_back(number);
        recvBytes+=DEFAULT_BUFLEN;
    }
    int countOfPackets=packets.size();
    for(int i=0;i<countOfPackets;i++)
    {
        for(int j=0;j<countOfPackets;j++)
        {
            if(numbers[j]==i)
            {
                strcat(recvbufn,packets[j]);
                delete(packets[j]);
            }
        }
    }
    return 0;
}
int sendA(SOCKET socket,char* recvbuf,int recvbuflen)
{
    send(socket,recvbuf,recvbuflen,0);
    fd_set readset;
    int result;
    do
    {
        FD_ZERO(&readset);
        FD_SET(socket, &readset);
        result = select(socket + 1, &readset, NULL, NULL, NULL);
    }
    while (result == -1 && errno == EINTR);

    if (result > 0)
    {
        char approve[1];
        if (FD_ISSET(socket, &readset))
        {
            /* The socket_fd has data available to be read */
            result = recv(socket, approve, 1, 0);
            if (result < 0)
            {
                /* This means the other side closed the socket */
                return -1;
            }
        }
    }
    return 0;
}

int main()
{

    int iResult = 0;

    WSADATA wsaData;

    SOCKET RecvSocket;
    sockaddr_in RecvAddr;

    unsigned short Port = 27015;

    char RecvBuf[DEFAULT_BUFLEN*2];
    int BufLen = DEFAULT_BUFLEN;

    sockaddr_in SenderAddr;
    int SenderAddrSize = sizeof (SenderAddr);

    //-----------------------------------------------
    // Initialize Winsock
    iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != NO_ERROR)
    {
        wprintf(L"WSAStartup failed with error %d\n", iResult);
        return 1;
    }
    //-----------------------------------------------
    // Create a receiver socket to receive datagrams
    RecvSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (RecvSocket == INVALID_SOCKET)
    {
        wprintf(L"socket failed with error %d\n", WSAGetLastError());
        return 1;
    }
    int SendSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (SendSocket == INVALID_SOCKET) {
        wprintf(L"socket failed with error: %ld\n", WSAGetLastError());
        WSACleanup();
        return 1;
    }
    //-----------------------------------------------
    // Bind the socket to any address and the specified port.
    RecvAddr.sin_family = AF_INET;
    RecvAddr.sin_port = htons(Port);
    RecvAddr.sin_addr.s_addr = inet_addr(IP_ADDRESS);
    sockaddr_in SendAddr;
    int len=sizeof(SendAddr);
    iResult = bind(RecvSocket, (SOCKADDR *) & RecvAddr, sizeof (RecvAddr));
    if (iResult != 0)
    {
        wprintf(L"bind failed with error %d\n", WSAGetLastError());
        return 1;
    }
    printf("-Starting client at %s:%d\n",inet_ntoa(RecvAddr.sin_addr),ntohs(RecvAddr.sin_port));
    //-----------------------------------------------
    // Call the recvfrom function to receive datagrams
    // on the bound socket.
    wprintf(L"Receiving datagrams...\n");
    recvfrom(RecvSocket,RecvBuf,sizeof(RecvBuf),0,(SOCKADDR *)&SendAddr,&len);
    iResult = connect(RecvSocket, (SOCKADDR *) & SendAddr, sizeof (SendAddr));
    if (iResult != 0)
    {
        wprintf(L"Connect failed with error %d\n", WSAGetLastError());
        return 1;
    }
  //  while(true)
 //   {
        iResult = readUDP(RecvSocket,RecvBuf,sizeof(RecvBuf));//recvfrom(RecvSocket,
                       //    RecvBuf, BufLen, 0, (SOCKADDR *) & SenderAddr, &SenderAddrSize);
        if (iResult == SOCKET_ERROR)
        {
            wprintf(L"recvfrom failed with error %d\n", WSAGetLastError());
        }


      //  int number;
      //  char message[DEFAULT_BUFLEN];
      //  data_pair data;
     //   getData(RecvBuf,number,message);
    //    printf("%d %s from %s:%d\n",number,message, inet_ntoa(SenderAddr.sin_addr),ntohs(SenderAddr.sin_port));
        printf("%s \n", RecvBuf);
         wprintf(L"Completed.\n");
//    }
    //-----------------------------------------------
    // Close the socket when finished receiving datagrams
    iResult = closesocket(RecvSocket);
    if (iResult == SOCKET_ERROR)
    {
        wprintf(L"closesocket failed with error %d\n", WSAGetLastError());
        return 1;
    }

    //-----------------------------------------------
    // Clean up and exit.
    wprintf(L"Exiting.\n");
    WSACleanup();
    return 0;
}
