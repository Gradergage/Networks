#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <arpa/inet.h>
#include <vector>
#include <mutex>
#include <pthread.h>
#include <iostream>
#include <thread>
#include <fcntl.h>
#include <string>
#define DEFAULT_BUFLEN 512
#define BLOCK_SIZE 16384
#define SOCKET int
#define MAX_PACKLEN 512*3
#define DEFAULT_BUFLEN 512
#define PREFIXLEN 11
#include "UDP.h"
//+11 char bytes, so 523
using namespace std;

int PORT=0;
char IP_ADDRESS[]="192.168.213.1";//="192.168.213.1";

struct CLIENT_INFO
{
    char login[DEFAULT_BUFLEN];
    char password[DEFAULT_BUFLEN];
    bool online=false;
};

struct CLIENT
{
    int id;
    SOCKET sock;
    sockaddr_in addr;
    bool connected;
    std::thread * cTh;
    CLIENT_INFO info;
    int lowBound;

};
std::vector <CLIENT *> clients;


int main()
{
    int iResult = 0;
    SOCKET sock;
    int iFamily = AF_INET;
    int iType = SOCK_DGRAM;
    int iProtocol = IPPROTO_UDP;

    sock = socket(iFamily,iType,iProtocol);

    sockaddr_in service;
    service.sin_family = AF_INET;
    service.sin_addr.s_addr = htonl(INADDR_ANY);
    service.sin_port = htons(PORT);


    //  char str[512]="215212 1234567";
    //  char message[512]="2544323";
    //  int number;
    //  getData(str,number,message);

    //  printf("%d/%s\n",number,message);

    iResult = bind(sock, (struct sockaddr *)&service, sizeof (service));
//    if (iResult == SOCKET_ERROR) {
//        printf("bind function failed with error %d\n", WSAGetLastError());
//        iResult = closesocket(sock);
//        if (iResult == SOCKET_ERROR)
//            printf("closesocket function failed with error %d\n", WSAGetLastError());
//        WSACleanup();
//        return 1;
//    }
    printf("-Starting client at %s:%d\n",IP_ADDRESS,PORT);



    sockaddr_in sender;
    sender.sin_family = AF_INET;
    sender.sin_addr.s_addr = inet_addr(IP_ADDRESS);
    sender.sin_port = htons(27015);
    int len=sizeof(sender);
    char messagel[MAX_PACKLEN]="";
    char messageS[DEFAULT_BUFLEN]="";
    char testbuf[PREFIXLEN+DEFAULT_BUFLEN]="";
    char appbuf[2]="a";

    iResult=connect(sock,(struct sockaddr *)&sender,len);
    send(sock,messagel,sizeof(messagel),0);

    printf("Connected");


    memset(messagel,'_',sizeof(messagel));
    memset(messageS,'a',sizeof(messageS));


     ///test 1, dublicates recieve
    printf("test 1, duplicates\n");
    //strcpy(,"");

    strcpy(testbuf,"0 ");
    strncat(testbuf,messageS,DEFAULT_BUFLEN);
    send(sock,testbuf,sizeof(testbuf),0);
    recv(sock,appbuf,sizeof(appbuf),0);

    strcpy(testbuf,"1 ");
    memset(messageS,'b',sizeof(messageS));
    strncat(testbuf,messageS,DEFAULT_BUFLEN);
    send(sock,testbuf,sizeof(testbuf),0);
    recv(sock,appbuf,sizeof(appbuf),0);

    send(sock,testbuf,sizeof(testbuf),0);
    recv(sock,appbuf,sizeof(appbuf),0);

    strcpy(testbuf,"2 ");
    memset(messageS,'c',sizeof(messageS));
    strncat(testbuf,messageS,DEFAULT_BUFLEN);
    send(sock,testbuf,sizeof(testbuf),0);
    recv(sock,appbuf,sizeof(appbuf),0);
    //iResult=sendUDP(sock,messagel,siz;eof(messagel));
   // printf("%s \n", RecvBuf);


    ///test 2, mixed packets recieve
    printf("test 2, mixed packets\n");

    strcpy(testbuf,"0 ");
    memset(messageS,'a',sizeof(messageS));
    strncat(testbuf,messageS,DEFAULT_BUFLEN);
    send(sock,testbuf,sizeof(testbuf),0);
    recv(sock,appbuf,sizeof(appbuf),0);

    printf("approved\n");

    strcpy(testbuf,"2 ");
    memset(messageS,'c',sizeof(messageS));
    strncat(testbuf,messageS,DEFAULT_BUFLEN);
    send(sock,testbuf,sizeof(testbuf),0);
    recv(sock,appbuf,sizeof(appbuf),0);
    printf("approved\n");

    strcpy(testbuf,"1 ");
    memset(messageS,'b',sizeof(messageS));
    strncat(testbuf,messageS,DEFAULT_BUFLEN);
    send(sock,testbuf,sizeof(testbuf),0);
    recv(sock,appbuf,sizeof(appbuf),0);
    printf("approved\n");

    ///test 3, missing packets recieve
    printf("test 3, missing packets\n");
    recv(sock,appbuf,sizeof(appbuf),0);
    strcpy(testbuf,"");
    strcpy(messagel,"");
    //readUDP(sock,messagel,sizeof(messagel));

    recv(sock,testbuf,sizeof(testbuf),0);
    printf("%s ",testbuf);
    send(sock,appbuf,sizeof(appbuf),0);
    printf("approved \n");
    sleep(2);

    recv(sock,testbuf,sizeof(testbuf),0);
    printf("%s ",testbuf);
    printf("not approved \n");

    recv(sock,testbuf,sizeof(testbuf),0);
    printf("%s ",testbuf);
    send(sock,appbuf,sizeof(appbuf),0);
    printf("approved \n");

    recv(sock,testbuf,sizeof(testbuf),0);
    printf("%s ",testbuf);
    send(sock,appbuf,sizeof(appbuf),0);
    printf("approved \n");

    close(sock);

    return 0;
}
